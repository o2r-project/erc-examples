library(raster)
library(rgdal)
install.packages("ncdf4")
library(ncdf4)
tifs <- dir("tif") #list the tif files
tifs

precipitation = stack(file.path("tif",tifs)) #load the tifs as a raster stack
spplot(precipitation) #plot the dataset
readOGR("aoi.shp","aoi")->aoi #an AOI used to extract the data

proj4string(aoi) #check if projection match...

proj4string(precipitation)

aoi.proj <- spTransform(aoi,proj4string(precipitation)) #transform to match the projections
aoi.lay <- list("sp.polygons", as(aoi.proj,"SpatialLines"), col = "red") 
spplot(precipitation,sp.layout=list(aoi.lay))
extract(precipitation,aoi.proj,fun=mean) #extract the mean precipitation in the AOI

stack("nc/TmaxForYears.nc")->temperatures #load the .nc file as a raster stack
temperatures 

spplot(temperatures)
aoi.temperature <- extract(temperatures,aoi.proj,fun=mean) #extract the mean temperature
t.axis <- colnames(aoi.temperature) #extract the dates in order to change them later into a valid axis
t.axis
t.axis <- gsub("X","",t.axis)
t.axis

t.axis <- as.POSIXct(t.axis,format="%Y.%m.%d",origin="1970-01-01")
t.axis
aoi.temperature <- data.frame(time=t.axis,temperature=as.vector(aoi.temperature))
aoi.temperature

plot(aoi.temperature) 
