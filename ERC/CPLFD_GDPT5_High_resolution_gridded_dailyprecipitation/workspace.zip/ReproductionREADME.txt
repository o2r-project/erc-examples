﻿#### Reproduction README ####

Note: working configuration of files and script in "workingReproduction.zip"


Prepare Data: 
	
1. Create following folders: r, r/tif, r/nc
	
2. Move CPLFD-GDPT../Alldata/NetCdf3/TmaxForYears.nc to r/nc
	
3. Move CPLFD-GDPT../Alldata/GeoTiff/PreciForDays/pre19930301 - pre19930331 to r/tif (31 files)
	
4. Create Shapefile aoi.shp with one polygon in Poland and defined CRS (e.g. WGS 84)
	
5. Move aoi.cpg, aoi.dbf, aoi.prj, aoi.sbn, aoi.sbx, aoi.shp, aoi.shx to r
	
6. add folder r to r.zip archive


Run docker container rocker/geospatial:3.4.0

Open RStudio in Browser
Upload r.zip and CDLFD-GDPT../script.R to RStudio

Set working directory to r

Run script

ERROR:
in line 19: stack("nc/TmaxForYears.nc")->temperatures

		
	Error: Loading required namespace: ncdf4
	
	Failed with error: ‘there is no package called ‘ncdf4’’
		
Error: requireNamespace("ncdf4") is not TRUE
	

FIX: 
package ncdf4 needs to be installed 
therefore, before running script enter

	> install.packages("ncdf4")

and add

 library(ncdf4)

in script.R after line 2


Run script
