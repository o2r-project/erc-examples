#' @get /figure9
#' @png (width = 700) 
function(newValue0) { 
startAnalysis <- Sys.time() 
newValue0=as.numeric(newValue0) 
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
playerID="ruthba01" #ruthba01, orourji01
# Base ball case study ============================================
baberuth <- subset(baseball, id == playerID)
baberuth <- transform(baberuth, cyear = year - min(year) + 1)
baseball <- ddply(baseball, .(id), transform, 
  cyear = year - min(year) + 1)
baseball <- subset(baseball, ab >= 25)
model <- function(df) {
  lm(rbi / ab ~ cyear, data=df)
}
model(baberuth)
bmodels <- dlply(baseball, .(id), model)


# ----------------------------

rsq <- function(x) summary(x)$r.squared
bcoefs <- ldply(bmodels, function(x) c(coef(x), rsquare = rsq(x)))
names(bcoefs)[2:3] <- c("intercept", "slope")
binwidthVal = newValue0

plot(qplot(rsquare, data=bcoefs, geom="histogram", binwidth=binwidthVal))

endAnalysis <- Sys.time() 
totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
message(paste("Total time is: ", totaltime)) 
}