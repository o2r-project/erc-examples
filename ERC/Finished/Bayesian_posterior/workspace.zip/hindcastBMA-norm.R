#compute model weights using posterior from the model output as a prior
source("load_obs.R")
source("load_models.R")
source("BMAutils.R")

statesFull=c('FW', 'NENW', 'NC', 'Hun', 'CWO', 'MM', 'CC', 'Msyd', 'Ill', 'SET', 'ACT', 'Victoria')


season="DJF" 
period="hindcast"  #"hindcast" for 1990-2009 or "forecast" for
           #  2060-2079


library(MCMCpack)
NDRAW=5000
BURN=500
KEEP=1
nSAMPLES=NDRAW



file1=paste("Yanan-results/", season, "/",  "weight1.txt", sep="")
weightMat1=read.table(file1)
file2=paste("Yanan-results/", season, "/", "weight2.txt", sep="")
weightMat2=read.table(file2)
file3=paste("Yanan-results/", season, "/",  "weight.txt", sep="")
weightMat=read.table(file3)


par(mfrow=c(3,4))
for (nState in c(1:12)) {
  
  region=statesFull[nState]
  obs=load.obs(season, region)
  model=load.reg.models(season, period, region)
  obs$years=obs$years-obs$years[1]+ length(obs$years)/2

  model$years=model$years-model$years[1]+ length(model$years)/2
  nObs=length(obs$years)
  
  obsout=MCMCregress(obs$obs~obs$years, thin=KEEP, mcmc=NDRAW)
  obsbeta0=obsout[,1]
  obsbeta1=obsout[,2]
  obssigma=obsout[,3]
  
  
  beta0Mat=beta1Mat=sigmaMat=matrix(NA, nrow=12, ncol=nSAMPLES)
  for (i in c(1:12)) {
 #first figure out how to correct the variance
    out=MCMCregress(model$allmodels[i,]~model$years, thin=KEEP, mcmc=NDRAW)
                  # b0=mean(obsbeta0), b1=0,
                  #B0=c(1.5/var(obsbeta0), 0.00001))
    beta0Mat[i,]=out[,1]
    beta1Mat[i,]=out[,2]
    sigmaMat[i,]=out[,3]
  }
 
 yy=c()
 wwy1=wwy2=wwy3=rep(0, nObs)
for (i in c(1:12)) {
  yy=mean(beta0Mat[i,])+mean(beta1Mat[i,])*obs$years
  wwy1=wwy1+weightMat[nState,i]*yy
  wwy2=wwy2+weightMat1[nState,i]*yy
  wwy3=wwy3+weightMat2[nState,i]*yy
}

#plot(obs$years, obs$obs, main=region,ylim=c(min(obs$obs)-3,max(obs$obs)+3))
#lines(obs$years, wwy1, lwd=4)
#lines(obs$years, wwy2, lwd=4, col=3)
#lines(obs$years, wwy3, lwd=4, col=4)


file1=paste("Yanan-results/", season, "/", "hindens1.txt", sep="")
write(t(wwy1), file=file1,  ncol=nObs, append=T)
file2=paste("Yanan-results/", season, "/", "hindens2.txt", sep="")
write(t(wwy2), file=file2, ncol=nObs, append=T)
file3=paste("Yanan-results/", season, "/",  "hindens3.txt", sep="")
write(t(wwy3), file=file3, ncol=nObs, append=T)



} #end nstates








