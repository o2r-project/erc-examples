#### R Code for determining the 14C of a steady state homogeneous, one-pool model
##### uses the SoilR package and the Hua et al. (2013) Curve for the Southern Hemisphere
### First, install the SoilR package.

#install.packages("SoilR", "http://cran.us.r-project.org") ## repo is the repository (CRAN mirror or RForge, as needed)
##### Load the SoilR library
library(SoilR)
#Bind the IntCal13 dataset and Hua2013 for the Southern Hemisphere Zones 1,2
# This produces the atmospheric 14C record from 50,000 BP to 2010 in Years AD
ad=bind.C14curves(prebomb=IntCal13,postbomb=Hua2013$SHZone12,time.scale="AD")
## Plot the atmospheric record
plot(ad[,1:2],type="l")
plot(ad[,1:2],type="l",xlim=c(0,2010))
abline(v=1950,lty=2)
####### To estimate the Value of 14C as a function of time for a given Turnover time (TT)
## Example given is for 50 year TT (you can change the value as needed)
TT=50 ### Put in the value of the TT in years you wish to use (in years)
### Other factors will be calculated to make sure model is at steady state
k1=1/TT ### k1 is the decomposition rate (1/TT) in 1/yr
la = 1/8267 ### la is the radio-decay constant for radiocarbon 1/mean life
Fz = k1/(k1+la) ### Steady state pre-bomb estimate of the Absolute Fraction Modern (see Sierra et al. 2014)
DFz = 1000*(Fz-1) ### Expressed as Delta 14C
##### Other model inputs are calculated so as to have the model remain at steady state
LitterInput=10 # arbitrary inputs
Cinit=LitterInput*TT # Inventory at steady state = initial Cinventory (arbitrary units)
#### Next step is to run the model
## In SoilR the one pool model is a function that can be called
years=seq(1901,2010,by=0.5) # time scale for running the model (expressed in years AD)


Ex=OnepModel14(t=years,k=k1,C0=Cinit,F0=DFz,In=LitterInput, inputFc=ad) #Soil R modelfunction
C14t=getF14(Ex) # Extracts 14C for each year
Ct=getC(Ex) # Extracts C inventory for each year (check for steady state)
DEL = C14t[217,] # This extracts the 14C signature in the year 2010
## Next steps make a plot of 14C versus year
plot(C14Atm_NH,type="l",xlab="Year",ylab="Delta 14C (per mil)",xlim=c(1940,2010))
lines(years, C14t[,1], col=4)
points(2010, DEL, cex=1.5)
legend(
  "topright",
  c("Delta 14C Atmosphere", "Delta 14C in SOM"),
  lty=c(1,1),
  col=c(1,4),
  lwd=c(1,1),
  bty="n"
)
#####
C14t[217,] #This line will return only the Del14C for the year 2010 (to be compared with the measured value)
#########
#########
### This code generates a table and a plot of the 14C signature
#### expected in 2010 for the one-pool, homogeneous, steady state model
### assimung a range of TTs (1 to 2000 years).
## This generates a "lookup" table for comparing with the data
sol1=2000 ### This is the end TT, starts with 1 year
sols= data.frame(1:sol1, 1:sol1) ## makes a data frame of the right size
for(i in 1:sol1) ## number of calculations
{
  TT=i
  k1=1/TT
  la = 1/8267
  Fz = k1/(k1+la)
  DFz = 1000*(Fz-1)
  LitterInput=10
  Cinit=LitterInput*TT
  Cinit
  years=seq(1901,2010,by=0.5)
  Ex=OnepModel14(t=years,k=k1,C0=Cinit,F0=DFz,In=LitterInput, inputFc=ad)
  C14t=getF14(Ex)
  DEL = C14t[206,]
  sols[i,1] = i
  sols[i,2] = DEL
  i=i+1
}
## Write the whole file
write.csv(sols, file = "Solutions.csv")
## make a plot of the 14C expected in 2010 for each TT.
plot(sols[,1],sols[,2],xlab="TT",ylab="Delta 14C (per mil)")
     
     