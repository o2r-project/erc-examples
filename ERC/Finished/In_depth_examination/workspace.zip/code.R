#install.packages("likert")
#install.packages("sessioninfo")
#install.packages("here")
library(likert)
library(sessioninfo)
library(here)
sessioninfo::session_info()

surveydata <- read.csv("data/surveydata.csv")

cleanData = function(dataSet){
  deleteRows = c()
  for (i in 1:nrow(dataSet)){
    if (dataSet[i,dataSet$Date.submitted] == ""){
      deleteRows = union(deleteRows, c(i))
    }
  }
  
  #delete not submitted answers
  dataSet = dataSet[-deleteRows,]
  
  #delete columns which are not required: "Submissiondate", "language", "last page"
  dataSet<-dataSet[,-c(2,3,4)]  
  
  return(dataSet)
}

surveydata <- cleanData(surveydata)

geosciencesResults = surveydata[which (surveydata[8]=="Yes"),]
#biologyResults = questionnaireResults[which (questionnaireResults[5]=="Yes"),]
#computerScience = questionnaireResults[which (questionnaireResults[6]=="Yes"),]
#economics = questionnaireResults[which (questionnaireResults[7]=="Yes"),]
#humanities = questionnaireResults[which (questionnaireResults[9]=="Yes"),]
#law = questionnaireResults[which (questionnaireResults[10]=="Yes"),]
#mathematics = questionnaireResults[which (questionnaireResults[11]=="Yes"),]
#medicine = questionnaireResults[which (questionnaireResults[12]=="Yes"),]
#pyhsics = questionnaireResults[which (questionnaireResults[13]=="Yes"),]
#politics = questionnaireResults[which (questionnaireResults[14]=="Yes"),]

write.csv(geosciencesResults, "data/geosciencesResults.csv")

#How many write papers?
numWriter = nrow(geosciencesResults[which (geosciencesResults[2]=="Yes"),])
numWriter
#How many read papers?
numReader = nrow(geosciencesResults[which (geosciencesResults[3]=="Yes"),])
numReader
#How many read AND write?
numReadersAndWriters = nrow(geosciencesResults[which (geosciencesResults[2]=="Yes" & geosciencesResults[3]=="Yes"),])
numReadersAndWriters

demographics = function(dataSet, i, labels){
  barplot(table(dataSet[i]),
          main="Participants", xlab="", col=c("blue", "orange"),
          names.arg=labels)
  print(table(dataSet[i]))
}

demographics(geosciencesResults,61, c("18-25", "26-35", "36-45", "46-55", "56-65", "66+"))
demographics(geosciencesResults,62, c("Other", "Female", "Male"))

yearsInResearch = function(dataSet){
  temp = NULL
  for (i in 1:nrow(dataSet)){
    if (is.na(dataSet[i,63])){
      next
    }
    #One respondent indicated the year when s/he started research, not the years in research so far:
    else if (dataSet[i,63] == "2010"){
      temp[length(temp)+1] = 6
    }
    else{
      temp[length(temp)+1] = as.integer(dataSet[i,63])      
    }
  }
  print(mean(temp))
  print(sd(temp))
}

yearsInResearch(geosciencesResults)

likertPlot = function(dataSet, questions, x, y, scale, ordered){
  plotlevels <- scale
  subset = dataSet[,x:y]
  
  sapply(subset, class)
  sapply(subset, function(x) { length(levels(x)) } )
  
  for(i in 1:ncol(subset)){
    numAnswers=nrow(subset[which (subset[i]!=""),])
    colnames(subset)[i] = paste(sep="", questions[i],"\n(", numAnswers, ")")
  }
  
  for(i in seq_along(subset)) {
    subset[,i] <- factor(subset[,i], levels=plotlevels)
  }
  
  experimentdataset <- likert(subset)
  if(ordered){
    p=likert.bar.plot(experimentdataset, group.order = names(subset), 
                      low.color="grey70", neutral.color = "grey50", high.color = "grey30")
    p + theme(panel.background = element_rect(fill = "grey95"))
  }else{
    p = likert.bar.plot(experimentdataset,
                        low.color="grey70", neutral.color = "grey50", high.color = "grey30")
    p + theme(panel.background = element_rect(fill = "grey95"))
  }
}

#Scale
agreementScale1 = c("strongly disagree", "disagree", "neither agree nor disagree", "agree", "strongly agree")

#Tasks
whileReadingPapers = c("change the model to see if results change.",
                       "change input variables to the model to see if results are robust to changes.",
                       "leave out data records to see if results change.",
                       "compare the results with my results after changing input variables.",
                       "use the analysis with a different dataset.",
                       "see the code used to compute diagrams etc.",
                       "download the code used to compute diagrams etc.",
                       "see the datasets underlying the paper.",
                       "download the datasets underlying the paper.",
                       "use the datasets with a different analysis.",
                       "interact with figures (zooming/panning).",
                       "jump to other sources cited in the paper.",
                       "do nothing more than reading the paper."
)

#Calling plot function
likertPlot(geosciencesResults, whileReadingPapers, 40,52, agreementScale1, FALSE)

agreementScale2 = c("strongly disagree", "disagree", "neither disagree nor agree", "agree", "strongly agree")
searchAndAccess = c("source code", "dataset", "methods", "research questions", "hypothesis")
likertPlot(geosciencesResults, searchAndAccess, 53,57, agreementScale2, FALSE)

searchBy = c("spatial properties", "temporal properties", "thematic properties")
likertPlot(geosciencesResults, searchBy, 58,60, agreementScale2, FALSE)

comments = function(dataSet){
  comment = c()
  for (i in 1:nrow(dataSet)){
    if (dataSet[i,65] != ""){
      print(dataSet[i, 65])
    }
  }
}

comments(geosciencesResults)