#' @get /figure3
#' @png (width = 700) 
function(newValue0) { 
startAnalysis <- Sys.time() 
newValue0=as.numeric(newValue0) 
library("stringr")
library("plyr")
library("ggplot2")
library("MASS")
deaths <- readRDS("deaths.rds")
codes <- read.csv("icd-main.csv")
codes$disease <- sapply(codes$disease, function(x) str_c(strwrap(x, width = 30), 
  collapse = "\n"))
names(codes)[1] <- "cod"
codes <- codes[!duplicated(codes$cod), ]
hod2 <- count(deaths, c("cod", "hod"))
hod2 <- subset(hod2, !is.na(hod))
hod2 <- join(hod2, codes)
hod2 <- ddply(hod2, "cod", transform, prop = freq/sum(freq))

# Compare to overall abundance
overall <- ddply(hod2, "hod", summarise, freq_all = sum(freq))
overall <- mutate(overall, prop_all = freq_all/sum(freq_all))

hod2 <- join(overall, hod2, by = "hod")
devi <- ddply(hod2, "cod", summarise, n = sum(freq), dist = mean((prop - prop_all)^2))
filter = newValue0
devi <- subset(devi, n > filter)

# Find outliers
xlog10 <- scale_x_log10(breaks = c(100, 1000, 10000), labels = c(100, 1000, 10000), 
  minor_breaks = log10(outer(1:9, 10^(1:5), "*")))
devi$resid <- resid(rlm(log(dist) ~ log(n), data = devi))
plot(ggplot(devi, aes(n, resid)) + geom_hline(yintercept = 1.5, colour = "grey50") + geom_point() + 
  xlog10)

endAnalysis <- Sys.time() 
totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
message(paste("Total time is: ", totaltime)) 
}