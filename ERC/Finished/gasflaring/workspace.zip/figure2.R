#' @get /figure2
#' @png (width = 700) 
function(newValue0) { 
startAnalysis <- Sys.time() 
newValue0=as.numeric(newValue0) 
library(fields)
library(maps)

plot.quicklook <- TRUE
file.emis <- "./Step_3_integration/output/flare.average.2015.RData"
load(file.emis) # get emission data
lon           <- format(flare.average[,which(colnames(flare.average)=="lon")],digits=1,scientific=FALSE)          # deg
lat           <- format(flare.average[,which(colnames(flare.average)=="lat")],digits=1,scientific=FALSE)          # deg
if(plot.quicklook){
tab <- read.table("./Step_4_write_files_for_cosmoart/output/point.dat",skip = newValue0)
load("./Step_2_calc_emissions/flare.grid.RData")
ie_tot <- length(seq(startlon,endlon,by=dlon))-1
je_tot <- length(seq(startlat,endlat,by=dlat))-1
lon <- seq(startlon,startlon+dlon*ie_tot,length=ie_tot)
lat <- seq(startlat,startlat+dlat*je_tot,length=je_tot)

CO <- array(NA,dim=c(length(lon),length(lat)))
for (i in 1:(dim(tab)[1])){
  if(tab[i,1]=="CO"){ CO[tab[i,2],tab[i,3]] <- tab[i,4]} 
}
image.plot(lon,lat,CO/1000,xlim=c(-10,15),ylim=c(-10,10),main="CO emission (t h-1) for 2015 (TP15)",las=1,col=tim.colors(20))
map("world",add=TRUE)
grid()
}

endAnalysis <- Sys.time() 
totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
message(paste("Total time is: ", totaltime)) 
}