########################################################################
# Creating a gas flaring emission dataset
# R function - function including the gas flaring combustion reactions
# Konrad Deetz
# November 12, 2015
# linked to the publication of Deetz and Vogel (2016)
########################################################################

# The following equations are published in:
# Ismail, O., Umukoro, G., E., 2014: Modelling combustion reactions for 
# gas flaring and its resulting emissions", Journal of King Saud Universi-
# ty - Engineering Sciences

# These functions are loaded and used within the R script 3/5 (calc
# emissions).
 
# DEFINE ALL NECESSARY FUNCTIONS AND VALUES
# =========================================================================

# a) general functions
# ===========================================

calc.x <- function(beta){
# Calculate THC (total hydrocarbon) for carbon (C1-C6)

  if (length(beta)==1){
    x <- 1 * beta[1]

  }else if (length(beta)==2){
    x <- 1 * beta[1] + 2 * beta[2]

  }else if (length(beta)==3){
    x <- 1 * beta[1] + 2 * beta[2] + 3 * beta[3] 

  }else if (length(beta)==4){
    x <- 1 * beta[1] + 2 * beta[2] + 3 * beta[3] + 4 * beta[4] 

  }else if (length(beta)==5){
    x <- 1 * beta[1] + 2 * beta[2] + 3 * beta[3] + 4 * beta[4] + 5 * beta[5]

  }else if (length(beta)==6){
    x <- 1 * beta[1] + 2 * beta[2] + 3 * beta[3] + 4 * beta[4] + 5 * beta[5] + 6 * beta[6]

  }else{
    stop("ERROR in <FLARE_EMISSION_FUNCTIONS.R>: to many beta factors for
    calculating TC/TH. Enlarge the equation for HCs greater than hexane within
    calc.x, calc.y, the RTs and also the corresponding molar mass!")
  }

  return(x)
}

calc.y <- function(beta){
# Calculate THC (total hydrocarbon) for hydrogen (H4-H12)

  if (length(beta)==1){
    y <- 4 * beta[1]

  }else if (length(beta)==2){
    y <- 4 * beta[1] + 6 * beta[2]

  }else if (length(beta)==3){
    y <- 4 * beta[1] + 6 * beta[2] + 8 * beta[3] 

  }else if (length(beta)==4){
    y <- 4 * beta[1] + 6 * beta[2] + 8 * beta[3] + 10 * beta[4]

  }else if (length(beta)==5){
    y <- 4 * beta[1] + 6 * beta[2] + 8 * beta[3] + 10 * beta[4] + 12 * beta[5]

  }else if (length(beta)==6){
    y <- 4 * beta[1] + 6 * beta[2] + 8 * beta[3] + 10 * beta[4] + 12 * beta[5] + 14 * beta[6]

  }else{
    stop("ERROR in <FLARE_EMISSION_FUNCTIONS.R>: to many beta factors for
    calculating TC/TH. Enlarge the equation for HCs greater than hexane within
    calc.x, calc.y, the RTs and also the corresponding molar mass!")
  }

  return(y)
}

calc.z <- function(x,y,delta){
# a parameter depending on percentage of excess/deficiency of combustion air
# (z=4 for complete combustion)
  aa <- x + y/4
  bb <- delta * aa
  cc <- bb - x
  z <- y / cc
  return(z)
}

calc.AFR <- function(x,y,z){
# Air-fuel-ratio
  aa   <- x + y/z
  bb   <- 4.76 * 29
  cc   <- 12 * x + y  
  AFR <- (aa * bb) / cc
  return(AFR)
}

calc.b <- function(x,y,z){
# stoichometric coefficient of air in combustion (unknown)
  b <- x + y/z
  return(b)
}

calc.k <- function(x,y){
# stoichometric coefficient of air for complete combustion (k=b for z=4)
  k <- x + y/4 # b/delta alternatively
  return(k)
}

calc.d <- function(x,y,z,etta){
# stoichometric coefficient for the amount of excess oxygen in product of combustion
  aa <- 0.5 - etta/2
  bb <- x * aa
  cc <- 1/z - etta/4
  dd <- y * cc
  d <- bb + dd
  return(d)
}


# b) molar masses (g mol-1)
# ===========================================

M.C <- 12.0107
M.H <- 1.00794 
M.O <- 15.9994
M.N <- 14.0067
M.S <- 32.065

M.H2    <- 2 * M.H 
M.O2    <- 2 * M.O
M.N2    <- 2 * M.N 
M.H2O   <- 2 * M.H + 1  * M.O 
M.CO    <- 1 * M.C + 1  * M.O
M.CO2   <- 1 * M.C + 2  * M.O
M.H2S   <- 1 * M.S + 2  * M.H
M.SO2   <- 1 * M.S + 2  * M.O
M.NO    <- 1 * M.N + 1  * M.O
M.NO2   <- 1 * M.N + 2  * M.O
M.CH4   <- 1 * M.C + 4  * M.H
M.C2H6  <- 2 * M.C + 6  * M.H
M.C3H8  <- 3 * M.C + 8  * M.H
M.C4H10 <- 4 * M.C + 10 * M.H
M.C5H12 <- 5 * M.C + 12 * M.H
M.C6H14 <- 6 * M.C + 14 * M.H


# c) Reaction types
# ===========================================
#        RT1         RT2             RT3             RT4         RT5      RT6
# SO2     -           x               -               x           -        x
# NO      -           -               x               x           x        x
# NO2     -           -               -               -           x        x
#     T<=1200K 1200K<=T<=1600K 1200K<=T<=1600K 1200K<=T<=1600K T>=1600K T>=1600K

# REACTION TYPE 1
#################

RT.1 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sweet gas" without the formation of NOx 
# - no NOx formation (T < 1200K) 
# - no soot or VOC
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2

# products
  CO2 <- (etta * x  + a) * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x    * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)  * M.H2O
  H2  <- (1-etta) * y/2  * M.H2  
  O2  <-  d              * M.O2
  N2  <- (j + b * 3.76)  * M.N2  # N2(out)=N2(gas) (no evolution during the reaction)

  SO2 <- 0
  NO  <- 0
  NO2 <- 0

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


# REACTION TYPE 2
#################

RT.2 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sour gas" without the formation of NOx 
# - no NOx formation (T <= 1200K) 
# - no soot or VOC
# - H2S is the only source of SO2 in flared gas
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2
  H2S.in  <- m * M.H2S

# products
  CO2 <- (etta * x  + a)       * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x          * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)        * M.H2O
  H2  <- ((1-etta) * y/2 + m)  * M.H2  
  O2  <- (d-m)                 * M.O2
  N2  <- (j + b * 3.76)        * M.N2  # N2(out)=N2(gas) (no evolution during the reaction)
  SO2 <- m                     * M.SO2 # H2S is the only source of SO2 in flared gas

  NO  <- 0
  NO2 <- 0

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


# REACTION TYPE 3
#################

RT.3 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sweet gas" with formation of NOx (only NO)
# - NO formation (1200K <= T <= 1600K) 
# - no soot or VOC
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2

# products
  CO2 <- (etta * x  + a)       * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x          * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)        * M.H2O
  H2  <- (1-etta) * y/2        * M.H2 
  O2  <- d/2                   * M.O2
  N2  <- (j + b*3.76 - d/2)    * M.N2  # some N2 is released free and some transformed to NO
  NO  <- d                     * M.NO   

  SO2 <- 0
  NO2 <- 0

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


# REACTION TYPE 4
#################

RT.4 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sour gas" with formation of NOx (only NO)
# - NO formation (1200K <= T <= 1600K) 
# - no soot or VOC
# - H2S is the only source of SO2 in flared gas
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2
  H2S.in  <- m * M.H2S

# products
  CO2 <- (etta * x  + a)       * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x          * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)        * M.H2O
  H2  <- ((1-etta) * y/2 + m)  * M.H2 
  O2  <- d/2 - m               * M.O2
  N2  <- (j + b*3.76 - d/2)    * M.N2  # some N2 is released free and some transformed to NO
  NO  <- d                     * M.NO   
  SO2 <- m                     * M.SO2 # H2S is the only source of SO2 in flared gas

  NO2 <- 0

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


# REACTION TYPE 5
#################

RT.5 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sour gas" with formation of NOx (NO and NO2)
# - NO formation (T >= 1600K) 
# - no soot or VOC
# - thermal NOx higly dependend on peak flame temperature and stoichometric
#   ratio in the primary combustion zone
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2

# products
  CO2 <- (etta * x  + a)       * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x          * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)        * M.H2O
  H2  <- (1-etta) * y/2        * M.H2 
  O2  <- d/4                   * M.O2
  N2  <- (j + b*3.76 - d/2)    * M.N2  # some N2 is released free and some transformed to NO and NO2
  NO  <- d/2                   * M.NO   
  NO2 <- d/2                   * M.NO2 

  SO2 <- 0

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


# REACTION TYPE 6
#################

RT.6 <- function(x,y,z,a,m,b,d,j,etta,beta) {
# /////////////////////////////////////
# Incomplete combustion of "sour gas" with formation of NOx (NO and NO2)
# - NO formation (T >= 1600K) 
# - no soot or VOC
# - H2S is the only source of SO2 in flared gas
# - thermal NOx higly dependend on peak flame temperature and stoichometric
#   ratio in the primary combustion zone
# /////////////////////////////////////

# reactants
  CxHy.in <- beta[1] * M.CH4 + beta[2] * M.C2H6 + beta[3] * M.C3H8 + beta[4] * M.C4H10 + beta[5] * M.C5H12 + beta[6] * M.C6H14
  CO2.in  <- a * M.CO2           
  O2.in   <- b * M.O2 
  N2.in   <- (j + b * 3.76) * M.N2
  H2S.in  <- m * M.H2S

# products
  CO2 <- (etta * x  + a)       * M.CO2 # CO2(out)=CO2(gas)+CO2(burn) [CO(burn) got etta% of Cx]
  CO  <- (1-etta) * x          * M.CO  # CO(out)=CO(burn) [CO(burn) got 1-etta% of Cx]
  H2O <- (etta * y / 2)        * M.H2O
  H2  <- ((1-etta) * y/2 +m)   * M.H2 
  O2  <- (d/4 - m)             * M.O2
  N2  <- (j + b*3.76 - d/2)    * M.N2  # some N2 is released free and some transformed to NO and NO2
  NO  <- d/2                   * M.NO   
  NO2 <- d/2                   * M.NO2 
  SO2 <- m                     * M.SO2

  species           <- cbind(CO2,  H2O,  CO,  H2,  O2,  N2,  SO2,  NO,  NO2 )
  colnames(species) <- c   ("CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

  return(species)
} # /////////////////////////////////////


print("<R function - flare emission functions> loaded.") 
