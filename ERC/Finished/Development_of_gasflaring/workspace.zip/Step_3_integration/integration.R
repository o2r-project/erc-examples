########################################################################
# Creating a gas flaring emission dataset
# R Script 3/4 - averaging
# Konrad Deetz
# March 22, 2016
# linked to the publication of Deetz and Vogel (2016)
########################################################################

# Within this script all flare emissions of one grid box per day are summed 
# up to finally have one huge flare per box.

# load libraries
# -

# clean up
rm(list=ls())

# data directories
file.meta <- "../Step_2_calc_emissions/output/meta/flare_meta_2015.RData"
file.emis <- "../Step_2_calc_emissions/output/emis/flare_emis_2015_delta_0.95_etta_0.8_gaugepress_5_psi.RData"

# flare grid (according to definition in R Script 2/4
# (all flares which have locations outside the predefined grid are ignored)
load("../Step_2_calc_emissions/flare.grid.RData")
ie.tot <- length(seq(startlon,endlon,by=dlon))
je.tot <- length(seq(startlat,endlat,by=dlat))

# Merge data
# ========================================================================================
flare.CO <- array(NA,dim=c(ie.tot,je.tot))
flare.SO2 <- flare.CO
flare.NO <- flare.CO
flare.NO2 <- flare.CO
flare.CO2 <- flare.CO
flare.VOL <- flare.CO
flare.RH <- flare.CO
flare.ST <- flare.CO

# load files
# ======================================================================
load(file.meta)
load(file.emis)

# find flares which are in the same gridbox
flare.index <- as.numeric(paste(as.character(meta[,1]),as.character(meta[,2]),sep=""))
flare.unique.index <- unique(flare.index)

# go through these flares within this single gridbox
  for (iuniqueflare in 1:length(flare.unique.index)){
    index <- which(flare.index==flare.unique.index[iuniqueflare])
    ilon <- meta[index[1],1]
    ilat <- meta[index[1],2]

# ignore flares which are not in the predefined grid range
    if (ilon<=ie.tot & ilat<=je.tot){
      flare.CO[ilon,ilat]  <- sum(emis[index,which(colnames(emis)=="CO")],na.rm=TRUE)   # sum up emissions in a gridbox
      flare.SO2[ilon,ilat] <- sum(emis[index,which(colnames(emis)=="SO2")],na.rm=TRUE)  # sum up emissions in a gridbox 
      flare.NO[ilon,ilat]  <- sum(emis[index,which(colnames(emis)=="NO")],na.rm=TRUE)   # sum up emissions in a gridbox
      flare.NO2[ilon,ilat] <- sum(emis[index,which(colnames(emis)=="NO2")],na.rm=TRUE)  # sum up emissions in a gridbox 
      flare.CO2[ilon,ilat] <- sum(emis[index,which(colnames(emis)=="CO2")],na.rm=TRUE)  # sum up emissions in a gridbox 
      flare.VOL[ilon,ilat] <- sum(meta[index,which(colnames(meta)=="VOL-Flux (m3 s-1)")],na.rm=TRUE)/length(index)      # mean
      flare.RH[ilon,ilat]  <- sum(meta[index,which(colnames(meta)=="VIIRS-radiantheat (MW)")],na.rm=TRUE)/length(index) # mean 
      flare.ST[ilon,ilat]  <- sum(meta[index,which(colnames(meta)=="VIIRS-sourcetemp (K)")],na.rm=TRUE)/length(index)   # mean 
    } # ignore flares outside the grid
  }

# back to tabular format
# ========================================================================================
lon.vector <- rep(seq(1,ie.tot,by=1),je.tot)
lat.vector <- rep(seq(1,je.tot,by=1),each=ie.tot)

flare.average <- cbind(lon.vector,lat.vector,
                       c(flare.CO),
                       c(flare.SO2),
                       c(flare.NO),
                       c(flare.NO2),
                       c(flare.CO2),
                       c(flare.VOL),
                       c(flare.RH),
                       c(flare.ST))

# remove gridboxes without emissions
index <- which(is.na(flare.average[,9])==FALSE)
flare.average<-flare.average[index,]

# save the results
# ===========================================
colnames(flare.average) <- c("lon","lat","CO","SO2","NO","NO2","CO2","VOLSTREAM","RADHEAT","SOURCETEMP")
save(flare.average,file=paste("./output/flare.average.2015.RData",sep=""))

print("<R Script 3/4 - averaging> complete.")
