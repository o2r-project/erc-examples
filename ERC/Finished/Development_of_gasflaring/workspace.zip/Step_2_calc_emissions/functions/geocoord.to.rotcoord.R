########################################################################
# Creating a gas flaring emission dataset
# R function - function for transforming regular to rotated lon/lat
# Konrad Deetz
# November 12, 2015
# linked to the publication of Deetz and Vogel (2016)
########################################################################

function (lon,lat,pollon,pollat,polgam,startlon,startlat,dlon,dlat) {
  
# preliminary calculations
deg.to.rad <- pi/180
rad.to.deg <- 180/pi

zsinpol <- sin (deg.to.rad * pollat)
zcospol <- cos (deg.to.rad * pollat)
zlonpol <-      deg.to.rad * pollon
zlat    <-      deg.to.rad * lat
 
if (lon > 180.0) {
 zlon <- lon - 360.0
}else{  
 zlon <- lon
}
zlon  <- deg.to.rad * zlon
 
###############################################
# lon -> rlon
###############################################
 term.1 <- -sin(zlon-zlonpol) * cos(zlat)
 term.2 <- -zsinpol * cos(zlat) * cos(zlon-zlonpol) + zcospol * sin(zlat)

 if (term.2 == 0.0) {term.2 <- 1.0e-20}

 rlon <- rad.to.deg * atan2(term.1,term.2)

 if(rlon >= -180.0 & rlon <= 0.0) {
  rlon <- rlon + polgam
 }else if(rlon <= 180.0 & rlon >= 0.0) {
  rlon <- rlon - polgam
 }

###############################################
# lat -> rlat
###############################################
 term.1 <- sin(zlat) * zsinpol
 term.2 <- cos(zlat) * zcospol * cos(zlon-zlonpol)
 
 rlat  <- rad.to.deg * asin(term.1+term.2)
   
###############################################
# rotated coordinates -> gridboxes
###############################################
iix <- ((rlon - startlon) / dlon) + 1
iiy <- ((rlat - startlat) / dlat) + 1

result <-cbind(rlon,rlat,abs(round(iix)),abs(round(iiy)))
colnames(result)<-c("rlon","rlat","gridbox_lon","gridbox_lat")

return(result)
  
}
