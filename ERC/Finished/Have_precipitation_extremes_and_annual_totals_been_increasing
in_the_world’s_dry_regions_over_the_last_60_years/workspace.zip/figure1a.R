#' @get /figure1a
#' @png (width = 700) 
function(newValue0) { 
startAnalysis <- Sys.time() 
newValue0=as.numeric(newValue0) 
library(extRemes)
cur.param = c(1, 1, 0)
nref = newValue0
ngridcells = 10000
data.orig = sapply(1:ngridcells, FUN=function(x) {
  cur.revd = revd(n=16, loc=cur.param[1], scale=cur.param[2], shape = cur.param[3], type="GEV")
  # cur.revd[which(cur.revd < 0)] <- 0
  return(cur.revd)
})

mean.estimate = sapply(1:ngridcells, FUN=function(x) mean(data.orig[1:nref,x]))
data.anom = sapply(1:ngridcells, FUN=function(x) data.orig[,x] / mean.estimate[x])

# plot fig. 1a
plot(density(data.orig / mean(c(data.orig)), bw = 0.2), xlim=c(-1,4), ylim=c(0,0.6), main="", bty='n', col="black", xlab ="")
axis(side=1, at=seq(-1, 4, 0.2), labels=F, tcl =  -0.2)
axis(side=2, at=seq(0, 0.6, 0.02), labels=F, tcl =  -0.2)
lines(density(data.anom[9:16,], bw = 0.2), col="darkorange")
lines(density(data.anom[1:8,], bw = 0.2), col="cornflowerblue")
lines(x=rep(mean(data.anom[16,]), 2), y=c(0, 0.6), col="darkorange", lwd=1, lty = 2)
lines(x=rep(mean(data.anom[1,]), 2), y=c(0, 0.6), col="cornflowerblue", lwd=1, lty = 2)
arrows(x0= mean(data.anom[1,]), x1=mean(data.anom[16,]), y0=0, y1= 0, code = 2, length=0.03, col="black", lwd = 2)
arrows(x0= mean(data.anom[1,]), x1=mean(data.anom[16,]), y0=0.3, y1= 0.3, code = 2, length=0.03, col="black", lwd = 2)
arrows(x0= mean(data.anom[1,]), x1=mean(data.anom[16,]), y0=0.6, y1= 0.6, code = 2, length=0.03, col="black", lwd = 2)
legend("topright", c("Original PDF", "Ref. period PDF", "Out-of-base PDF"), col=c("black", "cornflowerblue", "darkorange"), lty = 1, lwd = 2, bty="n", cex = 0.8)

endAnalysis <- Sys.time() 
totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
message(paste("Total time is: ", totaltime)) 
}