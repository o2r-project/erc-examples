#' @get /figure1b
#' @png (width = 700) 
function(newValue0) { 
startAnalysis <- Sys.time() 
newValue0=as.numeric(newValue0) 
library(extRemes)

# function to make transparent colors:
make.transparent.color <- function(x, alpha = 80) {  
  temp = c(col2rgb(col = x))
  return(rgb(red=temp[1], green=temp[2], blue=temp[3], alpha=alpha, maxColorValue=256))
}
cur.param = c(1, 1, 0)
nref = 30
sample.size = 10000
repetitions = newValue0 # in published figure repetitions are set to 100

data.cube.normalization = sapply(X=1:repetitions, FUN=function(idx) {
  ngridcells = sample.size
  
  # 1. sample from GEV:
    data.orig = sapply(1:ngridcells, FUN=function(x) revd(n=60, loc=cur.param[1], scale=cur.param[2], shape = cur.param[3], type="GEV"))
  # 2. derive estimates for the mean:
    mean.estimate = sapply(1:ngridcells, FUN=function(x) mean(data.orig[1:nref,x]))
    mean.estimate1 = mean(c(data.orig))
  # 3. normalize with the mean estimates:  
    data.anom = sapply(1:ngridcells, FUN=function(x) data.orig[,x] / mean.estimate[x])
  print(idx)
  return(c(apply(X=data.anom, MARGIN=1, FUN=mean), apply(X=data.orig / mean.estimate1, MARGIN=1, FUN=mean)))  
})

# plot figure 1b.:
plot(c(1,1), xlim=c(1,60), ylim = c(0.96, 1.06), bty='n', 
     ylab = "Mean of GEV", xlab ="Time", type='n')
polygon(x = c(1:60,60:1), y=c(apply(X=data.cube.normalization[61:120,], MARGIN=1, FUN=quantile, probs=c(0.05)), rev(apply(X=data.cube.normalization[61:120,], MARGIN=1, FUN=quantile, probs=c(0.95)))),
        col=make.transparent.color("black"), angle=45, density = 35, border = NA)
polygon(x = c(31:60,60:31), y=c(apply(X=data.cube.normalization[31:60,], MARGIN=1, FUN=quantile, probs=c(0.05)), rev(apply(X=data.cube.normalization[31:60,], MARGIN=1, FUN=quantile, probs=c(0.95)))),
        col=make.transparent.color("darkorange"), border = NA, density = 35, angle=15)
polygon(x = c(1:30,30:1), y=c(apply(X=data.cube.normalization[1:30,], MARGIN=1, FUN=quantile, probs=c(0.05)), rev(apply(X=data.cube.normalization[1:30,], MARGIN=1, FUN=quantile, probs=c(0.95)))),
        col=make.transparent.color("cornflowerblue"), border = NA, density = 35, angle=105)
lines(x = 1:60, y=apply(X=data.cube.normalization[61:120,], MARGIN=1, FUN=mean), col="black", lwd=2)
lines(x = 1:60, y=apply(X=data.cube.normalization[1:60,], MARGIN=1, FUN=mean), lwd=2, col = "darkgray")
lines(x = 31:60, y=apply(X=data.cube.normalization[31:60,], MARGIN=1, FUN=mean), col="darkorange", lwd=2)
lines(x = 1:30, y=apply(X=data.cube.normalization[1:30,], MARGIN=1, FUN=mean), col="cornflowerblue", lwd=2)
legend("topleft", c("Original time series", "Ref. period time series", "Normalized time series"), col = c("black", "cornflowerblue", "darkorange"), bty='n', lty =1, lwd = 2, cex = 0.8)

endAnalysis <- Sys.time() 
totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
message(paste("Total time is: ", totaltime)) 
}